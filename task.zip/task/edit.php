<!DOCTYPE HTML> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--connect to css file-->
<link rel="stylesheet" href="style.css">
<title>Edit Data</title>
</head>
<body>
<?php
// define of variables 
$nameError = $emailError = $genderError = "";
$name = $email = $gender = "";

// if name is empty
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameError = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameError = "Only letters and white space are allowed";
    }
  }

  // if email is empty
  if (empty($_POST["email"])) {
    $emailError = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailError = "Invalid email";
    }
  }
    
// if gender is empty
  if (empty($_POST["gender"])) {
    $genderError = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
// form validation
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<?php
// connection to updatadata file
require_once("updatedata.php");
// to update data in database
if(isset($_GET['id']))
                        {
                            $user_id = $_GET['id'];
                            $query = "SELECT * FROM user WHERE id=? LIMIT 1";
                            $statement = $conn->prepare($query);
                            $statement->bindParam(1, $user_id, PDO::PARAM_INT);
                            $statement->execute();
                            $data = $statement->fetch(PDO::FETCH_ASSOC);
                        }
?>
<!--form for edit-->
<!--The form-->
<h1 class="h1">Please complete the form</h1>
<p class="p"><span class="error">* required field</span></p>
<form class="style" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<!--name of user-->
<b>Name:</b> 
<input type="text" name="name" placeholder="name" value="<?=(isset($data['naame'])?$data['naame']:"");?>">
  <span class="error">* <?php echo $nameError;?></span>
  <br><br>
  <!-- e-mail of user-->
  <b>E-mail:</b> 
<input type="text" placeholder="email" name="email" value="<?=(isset($data['email'])?$data['email']:"");?>">
  <span class="error">* <?php echo $emailError;?></span>
  <br><br>
   <!--gender of user-->
  <b>Gender:</b> 
<input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
<input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <span class="error">* <?php echo $genderError;?></span>
  <br><br>
   <!--button of submit-->
  <input type="submit" name="update" value="Submit">  
<!--to update data in database-->
  <input type="hidden" name="user_id" value="<?=$data['id']?>">
</form> 

</body>
</html>