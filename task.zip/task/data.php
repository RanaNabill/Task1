<?php
//connect to database
require_once("connect.php");
try {
$query = "SELECT id,naame, email FROM user";
$prepared = $conn->prepare($query);
$prepared->execute();
$result = $prepared -> fetchAll(PDO::FETCH_ASSOC);
 ?>
 <!--table for data of user-->
 <table class="table" border="1" cellpadding="10" cellspacing="0">
 <?php

 foreach($result as $data) {
   
   ?>
   <tr>
     <!--table headers-->
    <th>ID</th>
    <th>Name</th>
    <th>E-mail</th>
    <th>Action</th>
   </tr>
    <tr>
       <!--table data-->
   <td><?php echo $data['id']; ?> </td>
   <td><?php echo $data['naame']; ?> </td>
   <td><?php echo $data['email']; ?> </td>
   <td>
     <!--connect to delete file-->
    <form action="delete.php" method="POST">
       <!--delete button-->
        <button type="submit" name="delete_user" value="<?=$data['id']?>">Delete</button>
    </form>
</td>
<td>
   <!--edit icon-->
    <a href="edit.php?id=<?= $data['id']; ?>"> Edit</a>
</td>
    </tr>
    <?php
  }
  ?>
</table>
  <?php
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
?>