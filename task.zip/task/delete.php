<?php
// connect to database
require_once("connect.php");

if(isset($_POST['delete_user']))
{
    $user_id = $_POST['delete_user'];

    try {
// to delete data from database
        $query = "DELETE FROM user WHERE id=? LIMIT 1";
        $statement = $conn->prepare($query);
        $statement->bindParam(1, $user_id, PDO::PARAM_INT);
        $query_execute = $statement->execute();

    } catch(PDOException $e) {
        echo $e->getMessage();
    }
}

?>