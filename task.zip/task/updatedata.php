<head>
    <!--link to sweet alert-->
<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<?php      
// connection to database      
require_once("connect.php");

if(isset($_POST['update']))
{
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    

    try {
// to update data in database
        $query = "UPDATE user SET naame=:naame, email=:email WHERE id=:stud_id LIMIT 1";
        $statement = $conn->prepare($query);
        $statement->bindParam(':naame', $name);
        $statement->bindParam(':email', $email);
        $statement->bindParam(':stud_id', $user_id, PDO::PARAM_INT);
        $query_execute = $statement->execute();

        if($query_execute)
        {
            // sweet alert box
            echo '<a href="form.php"><h1>Back to the form</h1></a>' . '<script type="text/javascript">
                $(document).ready(function() {
                    swal({
                        title: "Done!",
                        text: "You updated data",
                        icon: "success",
                        button: "Ok",
                        timer: 2000
                    });
                });
            </script>';
            exit(0);
            }
        else
        {
      echo "failed to edit";
        exit(0);
           }

    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
?>