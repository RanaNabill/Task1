<?php
// connect to database
require_once("connect.php");
try {
  
  // prepare sql and bind parameters
  $stmt = $conn->prepare("INSERT INTO user (naame, email)
  VALUES (:naame, :email)");
  $stmt->bindParam(':naame', $name);
  $stmt->bindParam(':email', $email);
  $stmt->execute();
  echo "New records created successfully";
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
?>