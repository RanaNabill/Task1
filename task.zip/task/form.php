<!DOCTYPE HTML>  
<html>
<head>
  <!--connect to css file-->
<link rel="stylesheet" href="style.css">
</head>
<body>  
<?php
// define of variables 
$nameError = $emailError = $genderError = "";
$name = $email = $gender = "";

// if name is empty
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameError = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameError = "Only letters and white space are allowed";
    }
  }

  // if email is empty
  if (empty($_POST["email"])) {
    $emailError = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailError = "Invalid email";
    }
  }
    
// if gender is empty
  if (empty($_POST["gender"])) {
    $genderError = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
// form validation
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!--The form-->
<h1 class="h1">Please complete the form</h1>
<p class="p"><span class="error">* required field</span></p>
<form class="style" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<!--name of user-->
<b>Name:</b> 
<input type="text" name="name" placeholder="name" value="<?php echo $name;?>">
  <span class="error">* <?php echo $nameError;?></span>
  <br><br>
  <!-- e-mail of user-->
  <b>E-mail:</b> 
<input type="text" placeholder="email" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailError;?></span>
  <br><br>
   <!--gender of user-->
  <b>Gender:</b> 
<input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
<input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <span class="error">* <?php echo $genderError;?></span>
  <br><br>
   <!--button of submit-->
  <input type="submit" name="submit" value="Submit">  
</form> 
<?php
// for showing data in the form
if ($_SERVER["REQUEST_METHOD"] =="POST"&&!empty($_POST["name"]) &&!empty($_POST["email"])&&!empty($_POST["gender"]))
  {
   // code of insert file 
    require_once("insertdata.php");
    // code of and data file
    require_once("data.php");
}
?>
</body>
</html>